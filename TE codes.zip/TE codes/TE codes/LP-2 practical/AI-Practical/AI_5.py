def shopping_bot():
    print("🛍️ Welcome to ShopBot! I'm here to help you. Type 'exit' to leave.\n")

    while True:
        user = input("You: ").lower()

        if user in ['hi', 'hello', 'hey']:
            print("Bot: Hello! How can I assist you today?")
        elif "order" in user and ("status" in user or "track" in user):
            print("Bot: Please enter your order ID to track your order.")
        elif "return" in user:
            print("Bot: You can return items within 7 days of delivery. Would you like help starting a return?")
        elif "refund" in user:
            print("Bot: Refunds are processed within 5–7 business days after we receive the returned item.")
        elif "delivery" in user:
            print("Bot: Most orders are delivered within 3–5 business days.")
        elif "payment" in user:
            print("Bot: We accept credit/debit cards, UPI, and net banking.")
        elif "cancel" in user:
            print("Bot: You can cancel your order before it is shipped. Would you like to proceed?")
        elif "support" in user or "help" in user:
            print("Bot: You can contact customer support at support@shopbot.com or call 1800-123-456.")
        elif user in ['exit', 'quit', 'bye']:
            print("Bot: Thank you for shopping with us. Goodbye! 👋")
            break
        else:
            print("Bot: I'm sorry, I didn't understand that. Please ask something related to your order, delivery, payment, or returns.")

if __name__ == "__main__":
    shopping_bot()
