def evaluate_performance():
    print("Employee Performance Evaluation System\n" + "-"*40)

    questions = {
        "Is the employee punctual?": 1,
        "Is the quality of work good?": 2,
        "Does the employee work well in a team?": 1,
        "Is the employee innovative?": 1,
        "Does the employee show leadership skills?": 2
    }

    score = sum(weight for question, weight in questions.items()
                if input(f"{question} (yes/no): ").strip().lower() == 'yes')

    if score >= 7:
        level = "Excellent Performance"
    elif score >= 5:
        level = "Good Performance"
    elif score >= 3:
        level = "Satisfactory Performance"
    else:
        level = "Needs Improvement"

    print(f"\nEvaluation Result:\nTotal Score: {score}\nPerformance Level: {level}")

if __name__ == '__main__':
    evaluate_performance()
